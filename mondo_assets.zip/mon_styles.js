app = navigator.appName;
ns = (app == "Netscape");
if(ns) document.writeln("<LINK REL='stylesheet' HREF='mon_navigator.css' TYPE='text/css'>");
else
document.writeln("<LINK REL='stylesheet' HREF='mon_explorer.css' TYPE='text/css'>");